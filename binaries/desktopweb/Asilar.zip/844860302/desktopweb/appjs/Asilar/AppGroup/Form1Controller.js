define("Asilar/AppGroup/userForm1Controller", {
    //Type your controller code here 
});
define("Asilar/AppGroup/Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Asilar/AppGroup/Form1Controller", ["Asilar/AppGroup/userForm1Controller", "Asilar/AppGroup/Form1ControllerActions"], function() {
    var controller = require("Asilar/AppGroup/userForm1Controller");
    var controllerActions = ["Asilar/AppGroup/Form1ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
