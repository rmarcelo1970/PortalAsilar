define("AsilarPreCadastro/AppGroup/userForm1Controller", {
    //Type your controller code here 
});
define("AsilarPreCadastro/AppGroup/Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("AsilarPreCadastro/AppGroup/Form1Controller", ["AsilarPreCadastro/AppGroup/userForm1Controller", "AsilarPreCadastro/AppGroup/Form1ControllerActions"], function() {
    var controller = require("AsilarPreCadastro/AppGroup/userForm1Controller");
    var controllerActions = ["AsilarPreCadastro/AppGroup/Form1ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
